define([
    "jquery",
    "jquery/ui"
], function ($) {
    "use strict";
    $.widget('pushnotification.cleverpushadmin', {
        _create: function () {
            
        }
    });
    return $.pushnotification.cleverpushadmin;
});
